package main

import (
	"bitbucket.org/brunetto/goutils/readfile"
	"github.com/spf13/cobra"
	"bufio"
	"fmt"
	"path/filepath"
	"log"
	"os"
	"regexp"
	"strings"
	"strconv"
	"time"
)


// https://github.com/spf13/cobra

func main() {
	var (
		inFileName string
		fileN string
	)

	var SltCmd = &cobra.Command{
    Use:   "slt",
    Short: "Tools for StarLab simulation management",
    Long: `...`,
    Run: func(cmd *cobra.Command, args []string) {
        fmt.Println("Choose a sub-command.")
		},
	}
	
	var versionCmd = &cobra.Command{
    Use:   "version",
    Short: "Print the version number of slt",
    Long:  `All software has versions. This is slt's`,
    Run: func(cmd *cobra.Command, args []string) {
        fmt.Println("StarLab Tools v0.2")
		},
	}
	
	SltCmd.AddCommand(versionCmd)
	
	var ContinueCmd = &cobra.Command{
    Use:   "continue",
    Short: "Prepare the new ICs from the last STDOUT",
    Long:  `StarLab can restart a simulation from the last complete output.
    The continue command prepare the new ICs parsing the last STDOUT and writing
    the last complete snapshot to the new input file.`,
    Run: func(cmd *cobra.Command, args []string) {
        Continue (inFileName, fileN)
		},
	}
	
	SltCmd.AddCommand(ContinueCmd)
	
	ContinueCmd.Flags().StringVarP(&inFileName, "inputFile", "i", "", "Last STDOUT to be used as input")
	ContinueCmd.Flags().StringVarP(&fileN, "fileN", "n", "", "Number to be attached to the new IC file name")
	
	var ContinueAllCmd = &cobra.Command{
    Use:   "all",
    Short: "Prepare the new ICs from all the last STDOUTs",
    Long:  `StarLab can restart a simulation from the last complete output.
    The continue command prepare the new ICs parsing all the last STDOUTs and writing
    the last complete snapshot to the new input file.`,
    Run: func(cmd *cobra.Command, args []string) {
//         Continue (inFileName, fileN)
		fmt.Println("Placeholder for this function")
		},
	}
	
	ContinueCmd.AddCommand(ContinueAllCmd)
	
	var GenerateScriptCmd = &cobra.Command{
    Use:   "generateScripts",
    Short: "Prepare the new ICs from all the last STDOUTs",
    Long:  `StarLab can restart a simulation from the last complete output.
    The continue command prepare the new ICs parsing all the last STDOUTs and writing
    the last complete snapshot to the new input file.`,
    Run: func(cmd *cobra.Command, args []string) {
//         Continue (inFileName, fileN)
		fmt.Println("Placeholder for this function")
		},
	}
	
	ContinueCmd.AddCommand(GenerateScriptCmd)
	
	SltCmd.Execute()
	
} // END MAIN


/* 
 * ===========================================================================
 *                               LIBS
 * ===========================================================================
 */

func Continue (inFileName string, fileN string) () {
	// FIXME: generate ICs with templates
	// http://golang.org/pkg/text/template/
	// filepath.Glob(pattern string) (matches []string, err error)
	
	var (
		outFileName string
		inFile *os.File
		outFile *os.File
		err error
		nReader *bufio.Reader
		nWriter *bufio.Writer
		snapshots = make([]*Snapshot, 2)
		snpN int
		simulationStop int64 = 500
		thisTimestep int64 = 0
		randomSeed string
	)
	
	tGlob0 := time.Now()
	
	if inFileName == "" {
		log.Fatal("You need to specify an input file with the -i flag!!!")
	}
	
	if fileN == "" {
		log.Fatal("You need to specify a number for the new ICs with the -n flag!!!")
	}
	
	outFileName = In2outFile (inFileName, fileN)	
	log.Println("Output file will be ", outFileName)
	
	log.Println("Opening input and output files...")
	// FIXME: take into account .gz files
	
	// Open files
	if inFile, err = os.Open(inFileName); err != nil {panic(err)}
	defer inFile.Close()
	
	if outFile, err = os.Create(outFileName); err != nil {panic(err)}
	defer outFile.Close()
	
	// Create reader and writerq
	nReader = bufio.NewReader(inFile)
	nWriter = bufio.NewWriter(outFile)
	
	log.Println("Start reading...")
	// Read two snapshot each loop to ensure at least one of them is complete
	// (= I keep the previous read in memory in case the last is corrupted)
	for {
		if snapshots[0], err = ReadSnapshot(nReader); err != nil {break}
		if snapshots[1], err = ReadSnapshot(nReader); err != nil {break}
	}
	
	// Check integrity once the file reading is ended
	// First the last read, then the previous one
	if snapshots[1].Integrity == true {
		snpN = 1
	} else if snapshots[0].Integrity == true {
		snpN = 0
	} else {
		log.Println("Both last two snapshots corrupted on file ", inFileName)
		fmt.Println("Snapshot ", snapshots[1].Timestep, " is ", snapshots[1].Integrity)
		fmt.Println("Snapshot ", snapshots[0].Timestep, " is ", snapshots[0].Integrity)
		log.Fatal("Reading exit with error ", err)
	}
	// Info
	log.Println("Done reading, last complete timestep is ", snapshots[snpN].Timestep)
	thisTimestep, _ = strconv.ParseInt(snapshots[snpN].Timestep, 10, 64)
	log.Println("Set -t flag to ", simulationStop - thisTimestep)
	
	// Write last complete snapshot to file
	log.Println("Writing snapshot to ", outFileName)
	if err = WriteSnapshot(nWriter, snapshots[snpN]); err != nil {
		log.Fatal("Error while writing snapshot to file: ", err)
	}
	
	log.Println("Search for random seed...")
	randomSeed = DetectRandomSeed(inFileName)
	log.Println("Set -s flag to ", randomSeed)
	
	tGlob1 := time.Now()
	fmt.Println()
	log.Println("Wall time for all ", tGlob1.Sub(tGlob0))
}

// Create the output file name that will be the new IC for the restart
func In2outFile (inFileName, fileN string) (outFileName string) {
	var (
		extension string
		baseName string
		file string
		dir string
	)
	
	dir = filepath.Dir(inFileName)
	file = filepath.Base(inFileName)
	extension = filepath.Ext(inFileName)
	baseName = strings.TrimSuffix(file, extension)
	baseName = strings.TrimPrefix(baseName, "new_")
	outFileName = filepath.Join(dir, baseName) + "-IC-" + fileN + extension //FIXME detectare nOfFiles
	return outFileName
}

// Struct containing one snapshot
type Snapshot struct {
	Timestep string
	Integrity bool
	NestingLevel int
	Data []string	
}

// This function read one and only one snapshot at a time
func ReadSnapshot(nReader *bufio.Reader) (*Snapshot, error) {
	var (
		snap *Snapshot = new(Snapshot)
		line string
		err error
		regSysTime = regexp.MustCompile(`system_time\s*=\s*(\d+)`)
		resSysTime []string
		dataStartIdx int = 0
		dataEndIdx int
	)

	// Init snapshot container
	snap.Data = make([]string, 1)
	snap.Integrity = false
	snap.NestingLevel = 0
	
	for {
		// Read line by line
		if line, err = readfile.Readln(nReader); err != nil {
			if err.Error() == "EOF" {
				log.Println("File reading complete...")
				log.Println("Timestep not complete.")
				log.Println("Last ten lines:")
				dataEndIdx = len(snap.Data)-1
				
				// Check that we have more than 10 lines
				if dataEndIdx > 10 {
					dataStartIdx = dataEndIdx - 10
				}
				for idx, row := range snap.Data[dataStartIdx:dataEndIdx] {
					fmt.Println(idx, ": ", row)
				}
			} else {
				log.Println("Error while reading ", err)
				log.Println("Returning corrupted timestep.")
			}
			// Mark snapshot as corrupted
			snap.Integrity = false
			return snap, err
		}
		
		// Add line to the snapshots in memory
		snap.Data = append(snap.Data, line)
		
		// Search for timestep number
		if resSysTime = regSysTime.FindStringSubmatch(line); resSysTime != nil {
			snap.Timestep = resSysTime[1]
// 			log.Println("Reading timestep ", resSysTime[1])
		}
		
		// Check if entering or exiting a particle
		// and update the nesting level 
		if strings.Contains(line, "(Particle") {
			snap.NestingLevel++
		} else if strings.Contains(line, ")Particle") {
			snap.NestingLevel--
		}
		
		// Check whether the whole snapshot is in memory
		// (root particle complete) and if true, return
		if snap.NestingLevel == 0 {
// 			log.Println("Timestep ended with nesting: ", snap.NestingLevel)
			snap.Integrity = true
			log.Println("Timestep ", snap.Timestep, " integrity set to: ", snap.Integrity)
			return snap, err
		}
	}	
}
	
// Pick the snapshot line by line and write it to the
// output file
func WriteSnapshot(nWriter *bufio.Writer, snap *Snapshot) (err error) {
	for _, line := range snap.Data {
		_, err = nWriter.WriteString(line+"\n")
	}
	nWriter.Flush()
	return err
}	

func DetectRandomSeed(inFileName string) (randomSeed string) {
	var (
		line string
		regRandomSeed = regexp.MustCompile(`initial random seed\s*=\s*(\d+)`)
		resRandomSeed []string
		inFile *os.File
		err error
		nReader *bufio.Reader
		stdErrName string
	)
	
	stdErrName = strings.TrimPrefix(inFileName, "n")
	
	// Open file & create reader
	if inFile, err = os.Open(stdErrName); err != nil {log.Fatal(err)}
	defer inFile.Close()
	nReader = bufio.NewReader(inFile)
	
	for {
		if line, err = readfile.Readln(nReader); err != nil {
			log.Fatal("STDERR interrupted before the random seed was found!!!")
		}
		// Search for timestep number
		if resRandomSeed = regRandomSeed.FindStringSubmatch(line); resRandomSeed != nil {
			randomSeed = resRandomSeed[1]
			break
		}
	}
	return 	randomSeed
}










